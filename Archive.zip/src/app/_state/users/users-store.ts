import { EntityAdapter, EntityState, createEntityAdapter } from "@ngrx/entity";
import { createActionGroup, createFeature, createFeatureSelector, createReducer, emptyProps, on, props } from "@ngrx/store";

const UsersStoreKey = "users";

export interface Data {
    "id": 1,
    "title": string,
    "price":number,
    "description": string,
    "category": string,
    "image": string,
    "rating"?: {},
    show:boolean
}

export interface UsersState extends EntityState<Data> {}

const usersAdapter: EntityAdapter<Data> = createEntityAdapter<Data>();


export const initialState: UsersState = usersAdapter.getInitialState({});


export const UsersActions = createActionGroup({
    source: UsersStoreKey,
    events: {
        Init: emptyProps(),
        'Load Success': props<{ data: Data[] }>(),
    }
});
export const UsersReducer = createFeature({
    name: UsersStoreKey,
    reducer: createReducer(
        initialState,
        on(UsersActions.loadSuccess, (_, { data }) => usersAdapter.setAll(data, _))
    )
});

